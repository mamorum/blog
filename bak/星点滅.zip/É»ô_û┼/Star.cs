﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Star : MonoBehaviour {
  float pX, pY; // position
  float sXY; // scale
  float spdS;
  float a; // alpha
  float spdA; // alpha speed
  int delay, frame, scale; // frame count
  Layer layer; Transform t; SpriteRenderer sr;
  internal void Init(Layer l) {
    layer = l; t = transform;
    sr = GetComponent<SpriteRenderer>();
    Restore();
  }
  void Restore() {
    //-> frame
    delay = Ransu.Int(1, 8) * 60;
    frame = Ransu.Int(180, 300);
    //-> order in layer
    if (Ransu.Bool()) sr.sortingOrder = layer.front;
    else sr.sortingOrder = layer.back;
    //-> position
    pX = Ransu.Float(-8.64f, 8.64f);
    pY = Ransu.Float(-4.2f, 4.45f);
    Grids.Position(t, pX, pY);
    //-> scale
    sXY = Ransu.Float(0.24f, 0.44f);
    Grids.Scale(t, sXY);
    //-> scale speed
    scale = Ransu.Int(20, 40);
    spdS = Ransu.Float(0.002f, 0.004f);
    if (Ransu.Bool()) spdS *= -1f;
    //-> alpha
    a = Ransu.Float(0.4f, 0.7f);
    Grids.Alpha(sr, 0f);
    //-> alpha speed
    spdA = Ransu.Float(0.032f, 0.048f);
    if (a > 0.5f) spdA *= -1;
  }
  bool Delay() {
    if (delay == 0) {
      Grids.Alpha(sr, a);
      return false;
    }
    delay--;
    return true;
  }
  bool Done() {
    if (frame == 0) {
      Restore();
      return true;
    }
    frame--;
    return false;
  }
  void Scale() {
    if (scale == 0) {
      scale = Ransu.Int(20, 40);
      spdS *= -1f;
    } else {
      scale--;
      sXY += spdS;
      Grids.Scale(t, sXY);
    }
  }
  void Update() {
    if (Delay()) return;
    if (Done()) return;
    Scale();
    // alpha
    //a += spdA;
    //Grids.Alpha(sr, a);
  }
}

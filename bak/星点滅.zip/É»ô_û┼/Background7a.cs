﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background7a : Background {
  public GameObject prfbSnow01, prfbStar11;
  internal override void Create() {
    GameObject obj;
    //-> flying
    Fly7 flying;
    for (int i = 0; i < 12; i++) {
      obj = Instance(prfbSnow01);
      flying = obj.AddComponent<Fly7>();
      flying.Init(layer);
    }
    //-> star11
    Star star;
    for (int i = 0; i < 64; i++) {
      obj = Instance(prfbStar11);
      star = obj.AddComponent<Star>();
      star.Init(layer);
    }
    gameObject.SetActive(true);
  }
}
